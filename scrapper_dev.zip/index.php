<?php
require_once("scrapper.php");
// Lets test the crawler
$scrapper = new WebScrapper;
// echo $scrapper->crawler("https://edition.cnn.com/2018/11/15/politics/broward-county-recount-didnt-count/index.html");
$scrapper->scrap("https://edition.cnn.com/2018/11/15/politics/broward-county-recount-didnt-count/index.html");
 ?>